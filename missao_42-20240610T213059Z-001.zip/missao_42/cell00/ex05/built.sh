for folder_name in "$@"; do
	if [ -d "ex$folder_name" ]; then
		echo "Arquivo ja existe"
	else
		mkdir "ex$folder_name"
	fi	
done
