$(document).ready(function() {
    // Função para adicionar tarefas
    $('#add_task_button').click(function() {
        var task = $('#task_input').val();
        if (task.trim()!== '') {
            $('#ft_list').append('<div class="task" data-task="' + task + '">' + task + '</div>');
            $('#task_input').val('');
        }
    });

    // Função para remover tarefas
    $(document).on('click', '.task', function() {
        var taskToRemove = $(this).data('task');
        if (confirm("Você realmente deseja remover a tarefa '" + taskToRemove + "'?")) {
            $(this).remove();
        }
    });
});
