document.addEventListener("DOMContentLoaded", (event) => {
  loadTasks();
});
  
function addTask() {
  const taskInput = document.getElementById("task_input");
  const taskText = taskInput.value.trim();
  if (taskText) {
    createTaskElement(taskText);
    saveTasks();
    taskInput.value = ""; // limpa o campo de entrada após adicionar a tarefa
  }
}

function createTaskElement(taskText) {
  const taskDiv = document.createElement("div");
  taskDiv.className = "task";
  taskDiv.textContent = taskText;
  taskDiv.addEventListener("click", () => {
    if (confirm("Deseja remover esta tarefa?")) {
      taskDiv.remove();
      saveTasks()
    }
  });
  const taskList = document.getElementById("ft_list");
  taskList.insertBefore(taskDiv, taskList.firstChild);
}

function saveTasks() {
  const tasks = [];
  document.querySelectorAll("#ft_list .task").forEach((task) => {
    task.push(task.textContent);
  });
  document.cookie = 'tasks=${JSON.stringify(tasks)};path=/';
}

function loadTasks() {
  const cookies = document.cookie.split(";");
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.startsWith("tasks=")) {
      const tasks = JSON.parse(cookie.substring("tasks=".length));
      task.forEach((taskText) => {
        createTaskElement(taskText);
      });
      break
    }
  }
}

